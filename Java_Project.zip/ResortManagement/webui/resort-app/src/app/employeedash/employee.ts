export class Employee {
  employeeId: number;
  employeeName: string;
  email: string;
  phone: string;
  passKey: string;
}
