export class Coupon {
  couponId: string;
  expiryDate: string;
  discount: number;
  amenityId: number;
}
