export class Amenities {
  amenityId: number;
  employeeId: number;
  amenityName: string;
  price: number;
  amenityCategory: string;
}
