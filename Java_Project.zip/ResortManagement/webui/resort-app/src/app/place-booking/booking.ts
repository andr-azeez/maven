export class Booking {
  bookingId: number;
  bookingDate: string;
  quantity: number;
  totalAmt: number;
  amenityId: number;
  memberId: number;
  employeeId: number;
  status: string;
}
