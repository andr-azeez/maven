export class Member {
  memberId: number;
  memberName: string;
  email: string;
  phone: string;
  walletbalance: number;
  passKey: string;
  dateOfBirth: string;
  membershipDate: string;
}
